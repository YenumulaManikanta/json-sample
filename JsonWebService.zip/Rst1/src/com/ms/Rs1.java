package com.ms;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


	@Path("/user-login")
	public class Rs1 {
	 
	    @GET
	    @Path("/login/{userId}")
	    @Produces(MediaType.APPLICATION_JSON)
	    public Log getUserById(@PathParam("userLogin") String userLogin){
	         
	        Log log = new Log();
	        log.setUserId("123");
	        log.setUserPwd("359");
	        return log;
	    }
}
