package com.ms;

import org.codehaus.jackson.annotate.JsonProperty;

public class Log {
	
	@JsonProperty("Id")
    private String userId;
     
    @JsonProperty("Pwd")
    private String userPwd;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
     

}
